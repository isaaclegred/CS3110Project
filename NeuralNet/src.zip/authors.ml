let hours_worked = [24; 24]
